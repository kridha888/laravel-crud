<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use App\Models\Categorie;
use Illuminate\Http\Request;

class CategorieController extends Controller
{
    public function index(){
        $products=Categorie::get();
        return view('categories.index',['products'=>$products]);
    }

    public function create(){
        return view('categories.create');
    }

    public function store(Request $request){
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'required|mimes:jpeg,png,jpg|max:10000'

        ]);
        $imagename=time().'.'.$request->image->extension();
        $request->image->move(public_path('products'),$imagename);
        $product= new Categorie;
        $product->image=$imagename;
        $product->name=$request->name;
        $product->description=$request->description;
        

        $product->save();
        return back()->withSuccess('product succesfully');
    }
    public function edit($id){
        $product=categorie::where('id',$id)->first();
        return view('categories.edit',['product'=>$product]);
       

    }
    public function update(Request $request,$id){
        $request->validate([
            'name'=>'required',
            'description'=>'required',
            'image'=>'nullable|mimes:jpeg,png,jpg|max:10000'

        ]);

        $product=Categorie::where('id',$id)->first();

        if(isset($request->image)){
            $imagename=time().'.'.$request->image->extension();
        $request->image->move(public_path('products'),$imagename);
        $product->image=$imagename;
        }
        $product->name=$request->name;
        $product->description=$request->description;
        

        $product->save();
        return back()->withSuccess('product updated');

    }
}
