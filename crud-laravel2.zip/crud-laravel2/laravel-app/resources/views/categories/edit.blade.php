<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Navbar</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="/">Products</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      @if($message=Session::get('success'))
      <div class="alert alert-success alert-block">
        <strong>{{$message}}</strong>
      </div>
      @endif
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card mt-3 p-3">
                    <form method="POST" action="/product/{{$product->id}}/update" enctype="multipart/form-data">
                        @csrf
                        @method('PUT') 
                        <div class="form-group ">
                            <label>NAME</label>
                            <input type="text" name="name" class="form-control" value="{{old('name',$product->name)}}"/>
                            @if($errors->has('name'))
                            <span class="text-danger">{{$errors->first('name')}}</span>
                            @endif
                        </div>

                        <div class="form-group ">
                          <label>Description</label>
                          <textarea name="description" class="form-control" >{{old('description',$product->description)}}</textarea>
                          @if($errors->has('description'))
                          <span class="text-danger">{{$errors->first('description')}}</span>
                          @endif
                      </div>

                      <div class="form-group ">
                        <label>Image</label>
                       <input type="file" name="image" class="form-control"/>
                       @if($errors->has('image'))
                       <span class="text-danger">{{$errors->first('image')}}</span>
                       @endif
                    </div>

                    <button type="submit" class="btn btn-dark mt-3">Submit</button>
                    </form>
                </div>
                
            </div>
                
        </div>
        <h1>product new</h1>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
</body>
</html>